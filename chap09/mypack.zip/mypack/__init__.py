from mypack import app

# def hoge():
#   return 'hoge'
