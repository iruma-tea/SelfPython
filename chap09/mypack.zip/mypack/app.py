def app_func1():
    print('mypack/appのapp_func1を実行')


def app_func2():
    print('mypack/appのapp_func2を実行')


print('【import】mypack/app module')
