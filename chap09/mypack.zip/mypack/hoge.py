def hoge_func1():
    print('mypack/hogeのhoge_func1を実行')


def hoge_func2():
    print('mypack/hogeのhoge_func2を実行')


def func():
    print('【function】mypack/hoge')


print('【import】mypack/hoge module')
