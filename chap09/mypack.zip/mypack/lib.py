import hoge
# from . import hoge
# from .mysub import hoge


def main():
    hoge.func()
