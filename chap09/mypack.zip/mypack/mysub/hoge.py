def hoge_func1():
    print('mypack/mysub/hogeのhoge_func1を実行')


def hoge_func2():
    print('mypack/mysub/hogeのhoge_func2を実行')


def func():
    print('【function】mypack/mysub/hoge')


print('【import】mypack/mysub/hoge module')
