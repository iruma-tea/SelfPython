from .. import hoge


def main():
    hoge.func()
