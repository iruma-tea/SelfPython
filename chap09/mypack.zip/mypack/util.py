def util_func1():
    print('mypack/utilのutil_func1を実行')


def util_func2():
    print('mypack/utilのutil_func2を実行')


if __name__ == '__main__':
    print('【import】mypack/util module')
